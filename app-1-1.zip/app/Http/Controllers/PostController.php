<?php

namespace App\Http\Controllers;

use App\{Post, Category, Tag, User};
use Illuminate\Http\Request;
use App\Policies\PostPolicy;
use App\Http\Requests\PostRequest;

class PostController extends Controller
{
    public function index()
    {
        return view('posts.index', [
            'posts' => Post::latest()->paginate(10)
        ]);
    }

    public function create(Post $post)
    {
        
        return view("posts.create", [
            'post' => $post,
            'categories' => Category::get(),
            'tags' => Tag::get()
        ]);
    }

    public function store(PostRequest $request)
    {
        $thumbnail = request()->file('thumbnail') ? request()->file('thumbnail')->store("image/posts") : null;
        $attr = $request->all();
        $attr['slug'] = \Str::slug($request->title);
        $attr['category_id'] = request('category');
        $attr['thumbnail'] = $thumbnail;

        $post = auth()->user()->posts()->create($attr);
        $post->tags()->attach(request('tags'));

        session()->flash('success', "New post was created.");

        return redirect('posts');
    }

    public function show(Post $post)
    {   
        $posts = Post::where('category_id', $post->category_id)->latest()->limit(6)->get();
        return view('posts.show', [
            'post' => $post,
            'posts' => $posts,
        ]);
    }

    public function edit(Post $post)
    {
        return view('posts.edit', [
            'post' => $post,
            'categories' => Category::get(),
            'tags' => Tag::get()
        ]);
    }

    public function update(PostRequest $request, Post $post)
    {
        $this->authorize('update', $post);
        
        if(request()->file('thumbnail')){
            \Storage::delete($post->thumbnail);
            $thumbnail = request()->file('thumbnail')->store("image/posts");
        }else{
            $thumbnail = $post->thumbnail;
        }
        $attr = $request->all();
        $attr['category_id'] = request('category');
        $attr['thumbnail'] = $thumbnail;
        $post->update($attr);
        $post->tags()->sync(request('tags'));

        session()->flash('success', "New post was updated.");

        return redirect('posts');
    }

    public function destroy(Post $post)
    {
        $this->authorize('delete', $post);
        \Storage::delete($post->thumbnail);
        $post->tags()->detach();
        $post->delete();
        session()->flash('success', 'Post was deleted.');
        return redirect('posts');
    }
}
