<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\User::create([
            'name' => "Randy Abdul Rahman",
            'email' => "randyabdulrahman87@gmail.com",
            'username' => "Randyar",
            'password'=> bcrypt("randy123"),
        ]);
    }
}
